import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`
  <cart></cart>`
  // template:`
  
  // <h1> List Of Courses </h1>

  // <div>
  //     <p *ngFor="let course of courses">
  //       <course [details]="course"></course>
  //     </p>
  // </div> 
  
  // `
  // template: `
  //     <course [details]="course1"></course>
  //     <course [details]="course2"></course>
  //     <course></course>      
  // `,
})
export class AppComponent 
 { 
   name = 'Angular 5';
 courses:any[] =[
   {name: "Knockout",duration:'2 Days'},
 {name: "NodeJS",duration:'3 Days'},
 {name: "ExtJS",duration:'3 Days'}
 
]

}
