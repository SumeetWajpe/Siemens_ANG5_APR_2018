import {Pipe, PipeTransform} from '@angular/core';
@Pipe({name:'qty'})
export class QuantityPipe implements PipeTransform{

        transform(theInput:number,theArgs:string){

            if(theInput == 0){
                return "Out Of Stock";
            }

                return theInput + " " + theArgs;
}
}