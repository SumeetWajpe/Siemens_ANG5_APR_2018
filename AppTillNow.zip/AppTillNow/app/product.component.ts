

import {Component, Input} from '@angular/core';

@Component({
    selector:`product`,
    templateUrl:`./app/product.component.html`
})
export class ProductComponent{
    @Input()   prodDetails:any
    ={};

    isFree:boolean=true;
}