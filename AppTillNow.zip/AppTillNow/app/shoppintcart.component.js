"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var product_model_1 = require("./product.model");
var ShoppingCartComponent = (function () {
    function ShoppingCartComponent() {
        this.heading = "Shopping Cart";
        this.isSuccess = false;
        this.newProduct = new product_model_1.default();
        this.productToBeSearched = "";
        this.companyName = "";
        this.products = [
            new product_model_1.default('Laptop', 40000, 30, 3, 'https://rukminim1.flixcart.com/image/704/704/j431rbk0/computer/t/h/p/hp-notebook-original-imaev2zfjqfpf3ng.jpeg?q=70'),
            new product_model_1.default('LED TV', 50000, 30, 3, 'http://www.lg.com/in/images/tvs/md05602497/gallery/Large-940x620.jpg'),
            new product_model_1.default('Desktop', 20000, 30, 3, 'https://images-eu.ssl-images-amazon.com/images/I/41IjXCFmiRL._SL500_AC_SS350_.jpg'),
            new product_model_1.default('Mobile', 30000, 30, 3, 'https://assets.mspcdn.net/t_c-desktop-normal,f_auto,q_auto,d_c:noimage.jpg/c/8808-62-4.jpg'),
            new product_model_1.default('Camera', 50000, 30, 3, 'https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_left.png')
        ];
    }
    ShoppingCartComponent.prototype.ChangeHandler = function () {
        //change the model !
        this.heading = "Flipcart !";
    };
    ShoppingCartComponent.prototype.ChangeHeadingTwoWay = function (e) {
        this.heading = (e.target.value);
    };
    ShoppingCartComponent.prototype.HandleFormSubmit = function () {
        //??? add 
        var NewProductToBeadded = new product_model_1.default(this.newProduct.name, this.newProduct.price, this.newProduct.quantity, this.newProduct.rating, 'https://paramountseeds.com/wp-content/uploads/2014/07/no_image1.gif');
        this.products.push(NewProductToBeadded);
        this.newProduct = new product_model_1.default();
        // OR 
        // resetting the form !
        // this.products.push(this.newProduct);
        // this.newProduct ={};
    };
    return ShoppingCartComponent;
}());
ShoppingCartComponent = __decorate([
    core_1.Component({
        selector: "cart",
        templateUrl: "./app/shoppingcart.component.html"
        //     template:`   
        //     <h1> {{ heading }} </h1>
        //     <!--
        //     Company Name :  <input type="text" [(ngModel)]="companyName" />
        //    <div [ngSwitch]="companyName">
        //         <p *ngSwitchCase="'L&T'">L&T</p>
        //         <p *ngSwitchCase="'Microsoft'">Microsoft</p>
        //         <p *ngSwitchCase="'Accenture'">Accenture</p>
        //         <p *ngSwitchCase="'Siemens'">Siemens</p>
        //         <p *ngSwitchDefault> No Company With Such Name !</p>
        //    </div> -->
        //     <!--
        //     Heading : <input type="text" 
        //     [(ngModel)]="heading"
        //     />
        //     Is Success ? <input type="checkbox"
        //      [(ngModel)]="isSuccess" />
        //      <input type="button" 
        //     [ngClass]="'btn btn-success'"
        //      value="Styled !" />
        //      <input type="button" 
        //      [ngClass]="['btn','btn-primary','btn-lg']"
        //       value="Styled !" />
        //       <input type="button" 
        //       [ngClass]="{'btn':true,'btn-success':isSuccess,'btn-lg':!isSuccess}"
        //        value="Styled !" />
        // -->
        //   <!--  <input type="button" 
        //     class="btn" [class.btn-success]="isSuccess"
        //      value="Styled !" />
        //      <input type="button" 
        //     [style.backgroundColor]="isSuccess ? 'Green' : 'Red'"
        //       value="Styled !" />
        //       -->
        //    <!-- Heading : <input type="text" [value]="heading"     
        //     (input)="ChangeHeadingTwoWay($event)"
        //     /> -->
        //    <!-- <input type="button"
        //      value="Change Heading !"
        //      (click)="ChangeHandler()"     /> -->
        //     <!--<div *ngFor="let p of products">
        // <product [prodDetails]="p"></product>
        // </div> -->
        // <!--
        // Search For a Product Here : 
        // <input type="text" [(ngModel)]="productToBeSearched" />
        // <div  [ngSwitch]="productToBeSearched">
        //         <div *ngFor="let p of products">
        //             <div *ngSwitchCase="p.name">
        //                 <product [prodDetails]="p"></product>
        //             </div>
        //         </div>             
        //             <div *ngSwitchDefault>
        //                 <div *ngFor="let p of products">
        //                         <product [prodDetails]="p"></product>
        //                     </div>
        //         </div>
        //     </div>
        //     -->
        //     `
    })
], ShoppingCartComponent);
exports.ShoppingCartComponent = ShoppingCartComponent;
//# sourceMappingURL=shoppintcart.component.js.map