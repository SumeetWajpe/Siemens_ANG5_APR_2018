

import {Component, Input} from '@angular/core';

@Component({
    selector:`course`,
    template:`<h1> {{coursedetails.name}} </h1>
    <b> Duration : </b> {{coursedetails.duration}}
    `
})
export class CourseComponent{
   @Input('details')   coursedetails:any={name:"Angular",duration:'3 Days'};
}